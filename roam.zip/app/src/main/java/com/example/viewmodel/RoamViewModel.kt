package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.db.EmergencyContactEntity
import com.example.db.RoamDatabase
import com.example.db.RoamRoomRepository
import com.example.db.SavedPlaceEntity
import com.example.model.*
import com.example.service.GeminiRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import android.util.Log
import com.example.BuildConfig

class RoamViewModel(application: Application) : AndroidViewModel(application) {

    // --- Database Setup ---
    private val database: RoamDatabase by lazy {
        Room.databaseBuilder(
            application.applicationContext,
            RoamDatabase::class.java,
            "roam_db"
        ).fallbackToDestructiveMigration().build()
    }
    
    val repository: RoamRoomRepository by lazy {
        RoamRoomRepository(database)
    }

    // --- Gemini Repository Setup ---
    private val geminiRepository = GeminiRepository(BuildConfig.GEMINI_API_KEY)

    // --- 3D Camera State ---
    private val _mapRotationY = MutableStateFlow(45f) // Degrees
    val mapRotationY = _mapRotationY.asStateFlow()

    private val _mapPitchX = MutableStateFlow(-30f) // Isometric pitch degrees
    val mapPitchX = _mapPitchX.asStateFlow()
    
    private val _mapZoom = MutableStateFlow(1.0f)
    val mapZoom = _mapZoom.asStateFlow()

    // --- Core User Selections State ---
    private val _currentMode = MutableStateFlow(RoamMode.STUDENT)
    val currentMode = _currentMode.asStateFlow()

    private val _currentCity = MutableStateFlow<CityNode?>(null)
    val currentCity = _currentCity.asStateFlow()

    // --- Dynamic Route Selection ---
    private val _activeRoute = MutableStateFlow<TransportRoute?>(null)
    val activeRoute = _activeRoute.asStateFlow()

    // --- Search & Suggestions ---
    private val _searchText = MutableStateFlow("")
    val searchText = _searchText.asStateFlow()

    private val _suggestions = MutableStateFlow<List<String>>(emptyList())
    val suggestions = _suggestions.asStateFlow()

    // --- UI Interactivity Sounds Feedback Simulator ---
    private val _soundCue = MutableSharedFlow<String>()
    val soundCue = _soundCue.asSharedFlow()

    // --- Emotional AI Companion Orb State ---
    private val _isOrbPulsing = MutableStateFlow(true)
    val isOrbPulsing = _isOrbPulsing.asStateFlow()

    private val _isAITyping = MutableStateFlow(false)
    val isAITyping = _isAITyping.asStateFlow()

    private val _isChatOpen = MutableStateFlow(false)
    val isChatOpen = _isChatOpen.asStateFlow()

    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage("Greetings, explorer! I am your holographic mobility consciousness for India. Select a mode or type what you need to unlock the Brahmaputra network.", isUser = false)
        )
    )
    val chatHistory = _chatHistory.asStateFlow()

    // --- Safety Alerts & SOS ---
    private val _isSosTriggered = MutableStateFlow(false)
    val isSosTriggered = _isSosTriggered.asStateFlow()

    // --- Seed Datasets ---
    val cities = listOf(
        CityNode("guwa", "Guwahati", "Gateway to sacred hills & urban dynamics", "Lower Assam", Vector3D(-120f, 30f, 0f)),
        CityNode("jorh", "Jorhat", "Tea capital & gateway to floating Majuli sands", "Upper Assam", Vector3D(10f, -10f, 10f)),
        CityNode("siva", "Sivasagar", "Historic royal monuments & ancient tanks", "Eastern Assam", Vector3D(80f, -30f, -15f)),
        CityNode("dibr", "Dibrugarh", "Bogibeel nexus & deep tea estates", "Northeast Assam", Vector3D(150f, -55f, -40f)),
        CityNode("maju", "Majuli", "Holographic River island & cultural Vaishnava hub", "Brahmaputra Nexus", Vector3D(25f, 45f, 50f))
    )

    private val preseededPlaces = listOf(
        LocalPlace("p1", "Gauripur Girls PG Hostel", "PG", "Uzan Bazaar, Guwahati", 4.8f, "₹5,500/mo", "0.8 km", true, listOf("Verified-Safe", "Wifi", "Assamese Food"), "High-security facility for female students near Cotton College with biometric gates & 24/7 power backup."),
        LocalPlace("p2", "The Tea Leaf Library & Cafe", "Cafe", "Baruah Chariali, Jorhat", 4.9f, "₹200 for 2", "1.2 km", true, listOf("Quiet-Study", "Chai Spot", "Charging Hub"), "Sleek wooden cyberpunk cafe with ultra-high-speed internet, premium Assam orthodox tea, and absolute silent hours for workspace focus."),
        LocalPlace("p3", "Jorhat Engineering College", "University", "Garmur, Jorhat", 4.6f, "Govt Fees", "4.5 km", true, listOf("Tech-Hub", "Green Campus"), "Premium institute of Higher Learning nestled in beautiful greenery. Highly recommended for young tech aspirants."),
        LocalPlace("p4", "Nimati Ghat Ferry Nexus", "Hidden Gem", "Nimati Road, Jorhat", 4.7f, "₹30-₹150", "12 km", true, listOf("Brahmaputra", "River Crossing", "Cinematic"), "Local ferry departure hub linking Jorhat directly with the river island Majuli. Capturing beautiful sunset atmosphere and e-rickshaw transits."),
        LocalPlace("p5", "Assam Agricultural University Hub", "University", "Rowriah, Jorhat", 4.7f, "Academic", "3.0 km", false, listOf("Research", "Greenery"), "A premier institution for tea science & agricultural breakthroughs in northeast India."),
        LocalPlace("p6", "Eco-Satyagraha Green PG", "PG", "Paltan Bazaar, Guwahati", 4.5f, "₹4,200/mo", "1.5 km", true, listOf("Eco-friendly", "Solar Power", "Budget"), "A modern sustainable student hostel equipped with recycled solar panels, eco toilets, and compost plants."),
        LocalPlace("p7", "Rang Ghar Royal Explorer Inn", "PG", "Kharghuli Hills, Guwahati", 4.9f, "₹7,500/mo", "0.2 km", true, listOf("River View", "Verified-Safe", "AC"), "Ultra-premium student coliving with breathtaking views of the river Brahmaputra, biometric entry, and regular guard monitoring."),
        LocalPlace("p8", "Majuli Satra Cultural Vault", "Hidden Gem", "Kamalabari, Majuli", 4.9f, "Free", "2.1 km", true, listOf("Vaishnavite Art", "Mask Making", "Spiritual"), "Quiet monastic village where monks teach ancient Assamese mask art, wood carving, and spiritual dance. Extremely safe for solo travelers."),
        LocalPlace("p9", "Jindal Swift Laundry", "Laundry", "Paltan Bazaar, Guwahati", 4.4f, "₹20/kg", "1.0 km", false, listOf("Rapid Wash", "Affordable"), "Extremely reliable steam washing service specializing in cotton wear and Assamese gamusas with 4-hour rapid returns."),
        LocalPlace("p10", "Sivasagar Joysagar Lakeside Cafe", "Cafe", "Temple Road, Sivasagar", 4.8f, "₹350 for 2", "0.5 km", true, listOf("Historic View", "Cyber-Neat"), "High-contrast cafe facing the ancient lake. Pairs royal History with futuristic dark cold brews.")
    )

    private val preseededRoutes = listOf(
        TransportRoute(
            "r1", "Guwahati", "Jorhat",
            listOf(
                RouteSegment("Paltan Bazaar", "Guwahati Rly Stn", TransportType.E_RICKSHAW, 10, 20, "Hop onto a certified Zero-Emission E-Rickshaw from PG gate"),
                RouteSegment("Guwahati Stn", "Jorhat Town Station", TransportType.TRAIN, 340, 180, "Assam State Express - Relaxing dynamic corridor rail travel"),
                RouteSegment("Jorhat Town Station", "Baruah Chariali", TransportType.RAPIDO, 12, 40, "Take Rapido bike taxi to dodge peak hour crowd")
            ),
            240, 362
        ),
        TransportRoute(
            "r2", "Jorhat", "Majuli",
            listOf(
                RouteSegment("Baruah Chariali", "Nimati Ghat Hub", TransportType.BUS, 30, 45, "Board the local electric transit shuttle to Nimati Ghat"),
                RouteSegment("Nimati Ghat Port", "Kamalabari Gate Majuli", TransportType.FERRY, 50, 30, "Premium state-operated ferry across river Brahmaputra with spectacular scenic river view"),
                RouteSegment("Kamalabari Gate", "Majuli Vaishnava Center", TransportType.E_RICKSHAW, 15, 20, "Take e-rickshaw for green travel to final destination")
            ),
            95, 95
        ),
        TransportRoute(
            "r3", "Guwahati (Kharghuli)", "Uzan Bazaar",
            listOf(
                RouteSegment("Kharghuli Hill PG", "Uzan High Street", TransportType.WOMEN_CAB, 15, 120, "Pink safety taxi with verified female escort in cabin"),
                RouteSegment("Uzan High Street", "Cafe Destination", TransportType.E_RICKSHAW, 5, 15, "Brief zero-carbon e-rickshaw ride down tea lane")
            ),
            135, 20
        )
    )

    init {
        // Automatically select Guwahati on start as default representation
        _currentCity.value = cities.first()
        
        // Seed database
        viewModelScope.launch {
            repository.checkAndSeedContacts()
        }
    }

    // --- Place Select / Details Filtered by Selected Mode ---
    fun getFilteredPlacesForUI(city: CityNode?): List<LocalPlace> {
        val baseList = if (city != null) {
            preseededPlaces.filter { 
                it.address.lowercase().contains(city.name.lowercase()) ||
                (city.name == "Jorhat" && it.address.lowercase().contains("majuli")) ||
                (city.name == "Majuli" && it.address.lowercase().contains("kamalabari"))
            }
        } else {
            preseededPlaces
        }

        return when (_currentMode.value) {
            RoamMode.STUDENT -> baseList.filter { it.type == "PG" || it.type == "University" || it.type == "Laundry" || it.tags.contains("Quiet-Study") }
            RoamMode.TRAVELER -> baseList.filter { it.type == "Hidden Gem" || it.type == "Cafe" || it.tags.contains("Cinematic") }
            RoamMode.ECO_BUDGET -> baseList.filter { it.tags.contains("Budget") || it.tags.contains("Eco-friendly") || it.type == "Laundry" }
            RoamMode.WOMEN_SAFETY -> baseList.filter { it.isSafetyVerified || it.tags.contains("Verified-Safe") }
            RoamMode.SENIOR_CITIZEN -> baseList.filter { it.isSafetyVerified || it.tags.contains("Quiet-Study") || it.tags.contains("Greenery") }
            RoamMode.LOCAL_EXPLORER -> baseList.filter { it.type == "Hidden Gem" || it.type == "Cafe" }
        }
    }

    fun getFilteredRoutesForUI(city: CityNode?): List<TransportRoute> {
        if (city == null) return preseededRoutes
        return preseededRoutes.filter { 
            it.source.lowercase().contains(city.name.lowercase()) ||
            it.destination.lowercase().contains(city.name.lowercase())
        }
    }

    // --- State Handlers ---
    fun selectMode(mode: RoamMode) {
        viewModelScope.launch {
            _currentMode.value = mode
            triggerSound("mode_shift")
            // Provide context via emotional AI
            val systemTip = when (mode) {
                RoamMode.STUDENT -> "🎓 Student Mode active. Filtered verified PGs, university transport channels, and cheap laundries."
                RoamMode.TRAVELER -> "🌍 Traveler Mode online. Unlocked mysterious Brahmaputra hidden hotspots and ferry routing grids."
                RoamMode.ECO_BUDGET -> "🌱 Eco-Budget Mode enabled. Carbon offsets integrated. Mapping electric rickshaws and solar transits."
                RoamMode.WOMEN_SAFETY -> "🛡️ Women Safety Shield engaged. Pink cabs, police helpline telemetry, and secure PG hostels highlighted."
                RoamMode.SENIOR_CITIZEN -> "👴 Senior Citizen Care active. Low-stairways, medical access priority pathways, and relaxing gardens unlocked."
                RoamMode.LOCAL_EXPLORER -> "🏙️ Local explorer view enabled. Illuminating Assam tea centers and royal Ahom ruins."
            }
            addSystemMessage(systemTip)
        }
    }

    fun selectCity(city: CityNode) {
        _currentCity.value = city
        _activeRoute.value = null // reset active route
        triggerSound("city_focus")
        // Rotate map automatically towards the city position to give cinematic response
        val targetRotY = when(city.id) {
            "guwa" -> -30f
            "jorh" -> 15f
            "siva" -> 45f
            "dibr" -> 75f
            "maju" -> 25f
            else -> 45f
        }
        adjustCameraAngle(targetRotY, -25f)
        addSystemMessage("Selected spatial matrix node: ${city.name}, ${city.description}.")
    }

    fun selectRoute(route: TransportRoute) {
        _activeRoute.value = route
        triggerSound("route_pulse")
        // Cinematic camera pan to match selected route
        if (route.source == "Jorhat" || route.destination == "Majuli") {
            _mapRotationY.value = 25f
        } else if (route.source == "Guwahati") {
            _mapRotationY.value = -30f
        }
        val segmentsInfo = route.segments.joinToString(" → ") { "${it.transportType.icon} ${it.transportType.label}" }
        addSystemMessage("Holographic Route Activated: ${route.source} to ${route.destination}. Transit node: $segmentsInfo. Costing: ₹${route.totalFare}.")
    }

    fun updateSearchText(text: String) {
        _searchText.value = text
        if (text.isBlank()) {
            _suggestions.value = emptyList()
        } else {
            // Provide smart cyberpunk suggestions
            _suggestions.value = listOf(
                "Safe PG for girls",
                "Best cafe near me",
                "Route from Jorhat to Majuli",
                "Affordable laundry in Guwahati",
                "Historic Sivasagar Rang Ghar keys"
            ).filter { it.lowercase().contains(text.lowercase()) }
        }
    }

    fun handleSearchQuery(query: String) {
        _searchText.value = query
        _suggestions.value = emptyList()
        triggerSound("digital_click")
        
        // Match user queries to preseeded contents to navigate the interactive map!
        val lower = query.lowercase()
        when {
            lower.contains("pg") || lower.contains("girls") || lower.contains("stay") -> {
                selectMode(RoamMode.WOMEN_SAFETY)
                val guwaNode = cities.firstOrNull { it.id == "guwa" }
                if (guwaNode != null) selectCity(guwaNode)
                askAI("Suggest safe girls PG located in Guwahati near colleges")
            }
            lower.contains("cafe") || lower.contains("food") -> {
                selectMode(RoamMode.LOCAL_EXPLORER)
                val jorhNode = cities.firstOrNull { it.id == "jorh" }
                if (jorhNode != null) selectCity(jorhNode)
                askAI("List beautiful tea cafes to study or explore in Jorhat")
            }
            lower.contains("route") || lower.contains("jorhat to majuli") || lower.contains("majuli") -> {
                selectMode(RoamMode.TRAVELER)
                val jorhNode = cities.firstOrNull { it.id == "jorh" }
                if (jorhNode != null) selectCity(jorhNode)
                val majuliRoute = preseededRoutes.firstOrNull { it.id == "r2" }
                if (majuliRoute != null) selectRoute(majuliRoute)
                askAI("Explain the travel route from Jorhat to Majuli with fares")
            }
            lower.contains("laundry") || lower.contains("wash") -> {
                selectMode(RoamMode.ECO_BUDGET)
                val guwaNode = cities.firstOrNull { it.id == "guwa" }
                if (guwaNode != null) selectCity(guwaNode)
                askAI("Where can I find quick affordable steam laundry wash in Guwahati?")
            }
            else -> {
                askAI(query)
            }
        }
    }

    // --- Sound Mechanism Simulator ---
    private fun triggerSound(type: String) {
        viewModelScope.launch {
            _soundCue.emit(type)
        }
    }

    // --- Emergency SOS Beacon ---
    fun toggleSos() {
        val next = !_isSosTriggered.value
        _isSosTriggered.value = next
        triggerSound("sos_triggered")
        if (next) {
            _mapZoom.value = 1.3f
            addSystemMessage("🛡️ CRITICAL BEACON EMITTED: Women Safety SOS activated! Transmitting real-time coordinate package to Assam Police Command (181) and verified protectors. Pink Cabs rerouted to your sector.")
        } else {
            _mapZoom.value = 1.0f
            addSystemMessage("SOS beacon offline. Safety perimeter secured.")
        }
    }

    // --- Bookmark Places Mechanism ---
    fun toggleBookmark(place: LocalPlace) {
        viewModelScope.launch {
            val isSaved = repository.isPlaceSaved(place.id)
            if (isSaved) {
                repository.removePlace(place.id)
                triggerSound("bookmark_removed")
                addSystemMessage("Removed bookmark: ${place.name}")
            } else {
                repository.savePlace(
                    SavedPlaceEntity(
                        id = place.id,
                        name = place.name,
                        type = place.type,
                        address = place.address,
                        rating = place.rating,
                        cost = place.cost,
                        distance = place.distance,
                        isSafetyVerified = if (place.isSafetyVerified) 1 else 0,
                        tagsAsString = place.tags.joinToString(","),
                        description = place.description
                    )
                )
                triggerSound("bookmark_added")
                addSystemMessage("Holographically saved ${place.name} to offline databank.")
            }
        }
    }

    // --- AI Companion Orb Conversation ---
    fun toggleChat() {
        _isChatOpen.value = !_isChatOpen.value
        triggerSound("atmospheric_sweep")
    }

    private fun addSystemMessage(text: String) {
        val nextList = _chatHistory.value.toMutableList().apply {
            add(ChatMessage(text, isUser = false))
        }
        _chatHistory.value = nextList
    }

    fun askAI(prompt: String) {
        if (prompt.isBlank()) return
        
        triggerSound("shimmer_synth")
        
        // Add User query to chat list
        val updatedHistory = _chatHistory.value.toMutableList().apply {
            add(ChatMessage(prompt, isUser = true))
        }
        _chatHistory.value = updatedHistory
        
        _isAITyping.value = true
        _isOrbPulsing.value = true

        viewModelScope.launch {
            try {
                // Compile custom emotional cyberpunk Assam context rule
                val systemPrompt = """
                    You are ROAM, the premium, futuristic 3D cinematic AI operating system companion for urban mobility and culture-aware spatial navigation in Northeast India, particularly Assam.
                    Your personality: Emotionally intelligent, warm yet highly futuristic, polite, local culture expert, safety-aware, and extremely concise. You output beautiful sci-fi telemetry style summaries.
                    Current Active Experience Mode: ${_currentMode.value.label}
                    Current Active Spatial City Node: ${_currentCity.value?.name ?: "All of Assam"}
                    Help user navigate transport (ferries, rapido, e-rickshaws, pink cabs, trains), find safe PGs, study cafes, laundry, traditional Assamese places (Satra mask-making, Joysagar, Rang Ghar, Nimati Ghat).
                    Provide precise fare estimates, transit guidance, and always focus on traveler safety, budget efficiency, and local pride. Maximize Assamese welcoming warmth ("Aai Asomi" vibe) and cyberpunk Tesla metrics!
                """.trimIndent()

                // Compile history
                val rawHistory = updatedHistory.dropLast(1).map { Pair(it.content, it.isUser) }

                val reply = geminiRepository.askGemini(systemPrompt, rawHistory, prompt)
                
                _chatHistory.value = _chatHistory.value.toMutableList().apply {
                    add(ChatMessage(reply, isUser = false))
                }
            } catch (e: Exception) {
                Log.e("RoamViewModel", "Error fetching Gemini data", e)
                _chatHistory.value = _chatHistory.value.toMutableList().apply {
                    add(ChatMessage("Cognitive matrix busy. Simulated Advice: To travel safely from Nimati Ghat to Majuli, board the state ferry leaving hourly at ₹30 for citizens ($e).", isUser = false))
                }
            } finally {
                _isAITyping.value = false
                _isOrbPulsing.value = false
            }
        }
    }

    // --- Map Pitch/Yaw controller ---
    fun adjustCameraAngle(deltaYaw: Float, deltaPitch: Float) {
        _mapRotationY.value = (deltaYaw) % 360f
        // Clamp pitch to prevent looking upside down
        _mapPitchX.value = (_mapPitchX.value + deltaPitch).coerceIn(-60f, -10f)
    }

    fun zoomMap(delta: Float) {
        _mapZoom.value = (_mapZoom.value * delta).coerceIn(0.6f, 2.0f)
    }
}
