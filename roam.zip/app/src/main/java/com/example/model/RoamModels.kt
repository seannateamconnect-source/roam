package com.example.model

import androidx.compose.ui.graphics.vector.ImageVector

// Experience Modes for the App
enum class RoamMode(val label: String, val icon: String, val description: String) {
    STUDENT("Student", "🎓", "Find affordable PGs, top universities, study cafes, and cheap travel."),
    TRAVELER("Traveler", "🌍", "Explore Northeast India's hidden gems, ferry routes, and rich cultures."),
    ECO_BUDGET("Eco/Budget", "🌱", "E-rickshaws, shared autos, budget hostels, and carbon-neutral paths."),
    WOMEN_SAFETY("Women Safety", "🛡️", "Pink cabs, night-safety maps, verified-safe PGs, and instant SOS."),
    SENIOR_CITIZEN("Senior Citizen", "👴", "Accessible transit, quiet parks, medical hubs, and low-stair access."),
    LOCAL_EXPLORER("Local Explorer", "🏙️", "Discover Brahmaputra river sights, historic Sivasagar temples, and local tea cafes.")
}

// 3D vector map coordinates representation
data class Vector3D(val x: Float, val y: Float, val z: Float)

// City Representation (Assamese Context + Indian Cities)
data class CityNode(
    val id: String,
    val name: String,
    val description: String,
    val region: String,
    val position3D: Vector3D,
    val pulseFrequency: Float = 1.0f,
    val isAssam: Boolean = true
)

// Destination / Landmark details based on Modes
data class LocalPlace(
    val id: String,
    val name: String,
    val type: String, // "PG", "Cafe", "University", "Laundry", "Hidden Gem", "Temple"
    val address: String,
    val rating: Float,
    val cost: String, // "$", "$$", "$$$"
    val distance: String,
    val isSafetyVerified: Boolean,
    val tags: List<String>,
    val description: String
)

// Transport Options
enum class TransportType(val label: String, val icon: String, val averageSpeed: String, val emissions: String) {
    FERRY("Brahmaputra Ferry", "🚢", "15 km/h", "Low Carbon"),
    RAPIDO("Rapido Bike", "🏍️", "45 km/h", "Medium Carbon"),
    E_RICKSHAW("E-Rickshaw", "🛺", "20 km/h", "Zero Carbon"),
    BUS("Northeast Transit Bus", "🚌", "30 km/h", "Low Carbon"),
    METRO_CAB("Cyberpunk Cab", "🚗", "40 km/h", "Premium"),
    TRAIN("Indian Railways State Express", "🚂", "65 km/h", "Low Carbon"),
    WOMEN_CAB("Pink Safety Cab", "🌸", "40 km/h", "Zero Carbon")
}

data class TransportRoute(
    val id: String,
    val source: String,
    val destination: String,
    val segments: List<RouteSegment>,
    val totalFare: Int,
    val totalMinutes: Int
)

data class RouteSegment(
    val from: String,
    val to: String,
    val transportType: TransportType,
    val durationMin: Int,
    val fare: Int,
    val instruction: String
)

// Chat message structure for the Emotional AI Companion
data class ChatMessage(
    val content: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
