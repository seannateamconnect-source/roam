package com.example.service

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.util.Log
import java.util.concurrent.TimeUnit

// --- Compile-Safe Native API Client ---

object RetrofitClient {
    val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
}

class GeminiRepository(private val apiKey: String) {

    suspend fun askGemini(systemPrompt: String, history: List<Pair<String, Boolean>>, currentPrompt: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "🛡️ Holographic ROAM Assistant Active. (Welcome to Assam, explorer! Plug in a valid AI Studio Secrets API key under BuildConfig.GEMINI_API_KEY to activate full live response vectors)."
        }

        try {
            val jsonPayload = buildJsonPayload(systemPrompt, history, currentPrompt)
            val requestBody = jsonPayload.toRequestBody("application/json".toMediaType())

            // Utilizing current recommended stable endpoint gemini-1.5-flash
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey")
                .post(requestBody)
                .build()

            RetrofitClient.okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errCode = response.code
                    return@withContext "Holographic neural sync failed with code $errCode. Default advice: Secure a safe girl's PG in Guwahati, Paltan Bazaar (starts ₹4,200/mo) or enjoy majestic Brahmaputra river transits via daily Nimati ferry."
                }
                val bodyStr = response.body?.string() ?: ""
                parseTextResponse(bodyStr)
            }
        } catch (e: Exception) {
            Log.e("GeminiRepository", "Error in Gemini communication layer", e)
            "Cognitive link secured offline: ${e.localizedMessage ?: "No Signal"}. Filter parameters are loaded for local PG hostels, universities, tea cafes, and emergency women services."
        }
    }

    // Manual bulletproof JSON escape & assembly (Removes Kotlinx constraints entirely)
    private fun buildJsonPayload(systemPrompt: String, history: List<Pair<String, Boolean>>, currentPrompt: String): String {
        val json = StringBuilder()
        json.append("{")

        // systemInstruction
        json.append("\"systemInstruction\": {")
        json.append("\"parts\": [{\"text\": \"${escapeJson(systemPrompt)}\"}]")
        json.append("},")

        // contents
        json.append("\"contents\": [")
        val allHistory = history.map { Pair(it.first, if (it.second) "user" else "model") } + Pair(currentPrompt, "user")
        
        allHistory.forEachIndexed { idx, pair ->
            json.append("{")
            json.append("\"role\": \"${pair.second}\",")
            json.append("\"parts\": [{\"text\": \"${escapeJson(pair.first)}\"}]")
            json.append("}")
            if (idx < allHistory.size - 1) {
                json.append(",")
            }
        }
        json.append("],")

        // generationConfig
        json.append("\"generationConfig\": {")
        json.append("\"temperature\": 0.7,")
        json.append("\"maxOutputTokens\": 700")
        json.append("}")

        json.append("}")
        return json.toString()
    }

    private fun escapeJson(input: String): String {
        return input.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
    }

    // Deep deterministic manual response extraction
    private fun parseTextResponse(body: String): String {
        val targetKey = "\"text\":"
        val startIdx = body.indexOf(targetKey)
        if (startIdx == -1) return "Telemetry registered empty data segment."

        val remainder = body.substring(startIdx + targetKey.length)
        val quoteStart = remainder.indexOf("\"")
        if (quoteStart == -1) return "Telemetry capture anomaly."

        val startValue = quoteStart + 1
        val parsed = StringBuilder()
        var i = startValue
        var wasEscaped = false

        while (i < remainder.length) {
            val c = remainder[i]
            if (wasEscaped) {
                when (c) {
                    'n' -> parsed.append('\n')
                    't' -> parsed.append('\t')
                    'r' -> parsed.append('\r')
                    '\\' -> parsed.append('\\')
                    '\"' -> parsed.append('\"')
                    else -> parsed.append(c)
                }
                wasEscaped = false
            } else if (c == '\\') {
                wasEscaped = true
            } else if (c == '\"') {
                break // Met end of string candidate text
            } else {
                parsed.append(c)
            }
            i++
        }

        return parsed.toString()
    }
}
