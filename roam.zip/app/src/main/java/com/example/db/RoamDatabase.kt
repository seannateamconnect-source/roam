package com.example.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- Room Entities ---

@Entity(tableName = "saved_places")
data class SavedPlaceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val address: String,
    val rating: Float,
    val cost: String,
    val distance: String,
    val isSafetyVerified: Int, // 1 = true, 0 = false
    val tagsAsString: String, // Comma separated
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "emergency_contacts")
data class EmergencyContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val relation: String,
    val isDefault: Int = 0
)

// --- Daos ---

@Dao
interface SavedPlaceDao {
    @Query("SELECT * FROM saved_places ORDER BY timestamp DESC")
    fun getAllSavedPlaces(): Flow<List<SavedPlaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlace(place: SavedPlaceEntity)

    @Query("DELETE FROM saved_places WHERE id = :placeId")
    suspend fun deletePlaceById(placeId: String)

    @Query("SELECT EXISTS(SELECT * FROM saved_places WHERE id = :placeId)")
    suspend fun isPlaceSaved(placeId: String): Int
}

@Dao
interface EmergencyContactDao {
    @Query("SELECT * FROM emergency_contacts ORDER BY id ASC")
    fun getAllContacts(): Flow<List<EmergencyContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: EmergencyContactEntity)

    @Delete
    suspend fun deleteContact(contact: EmergencyContactEntity)

    @Query("SELECT COUNT(*) FROM emergency_contacts")
    suspend fun getContactsCount(): Int
}

// --- App Database Configuration ---

@Database(entities = [SavedPlaceEntity::class, EmergencyContactEntity::class], version = 1, exportSchema = false)
abstract class RoamDatabase : RoomDatabase() {
    abstract fun savedPlaceDao(): SavedPlaceDao
    abstract fun emergencyContactDao(): EmergencyContactDao
}

// --- Repository Pattern Implementation ---

class RoamRoomRepository(private val db: RoamDatabase) {
    val savedPlaces: Flow<List<SavedPlaceEntity>> = db.savedPlaceDao().getAllSavedPlaces()
    val emergencyContacts: Flow<List<EmergencyContactEntity>> = db.emergencyContactDao().getAllContacts()

    suspend fun savePlace(place: SavedPlaceEntity) {
        db.savedPlaceDao().insertPlace(place)
    }

    suspend fun removePlace(placeId: String) {
        db.savedPlaceDao().deletePlaceById(placeId)
    }

    suspend fun isPlaceSaved(placeId: String): Boolean {
        return db.savedPlaceDao().isPlaceSaved(placeId) > 0
    }

    suspend fun saveContact(contact: EmergencyContactEntity) {
        db.emergencyContactDao().insertContact(contact)
    }

    suspend fun removeContact(contact: EmergencyContactEntity) {
        db.emergencyContactDao().deleteContact(contact)
    }

    suspend fun checkAndSeedContacts() {
        if (db.emergencyContactDao().getContactsCount() == 0) {
            // Seed defaults for woman safety & transit help
            db.emergencyContactDao().insertContact(
                EmergencyContactEntity(name = "Assam Police Women Helpline", phone = "181", relation = "Govt Helpline", isDefault = 1)
            )
            db.emergencyContactDao().insertContact(
                EmergencyContactEntity(name = "National Emergency Support", phone = "112", relation = "SOS Guard Service", isDefault = 1)
            )
            db.emergencyContactDao().insertContact(
                EmergencyContactEntity(name = "Guwahati Transit Safety Command Center", phone = "+91-361-2462222", relation = "Transit Command", isDefault = 1)
            )
        }
    }
}
