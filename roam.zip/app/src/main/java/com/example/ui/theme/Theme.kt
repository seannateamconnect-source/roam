package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = RoamPurpleGlow,
    secondary = RoamIndianAccent,
    tertiary = RoamTextMuted,
    background = RoamBackground,
    surface = RoamSecondarySurface,
    onPrimary = RoamTextPrimary,
    onSecondary = RoamBackground,
    onTertiary = RoamTextPrimary,
    onBackground = RoamTextPrimary,
    onSurface = RoamTextPrimary
  )

private val LightColorScheme = DarkColorScheme // All modes are cinematic dark in ROAM

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force cinematic dark environment
  dynamicColor: Boolean = false, // Enforce brand-cohesive colors
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
