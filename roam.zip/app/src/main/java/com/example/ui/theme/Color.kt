package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium ROAM Cyberpunk India Color Scheme
val RoamBackground = Color(0xFF070B14)      // Cinematic Deep Dark Space
val RoamSecondarySurface = Color(0xFF111827) // Steel Sleek Gray Surface
val RoamPurpleGlow = Color(0xFF7C5CFF)       // Holographic Neon Purple
val RoamIndianAccent = Color(0xFFFF7A1A)     // Warm Saffron Orange Accent
val RoamTextPrimary = Color(0xFFF8FAFC)      // Crisp Off-White Text
val RoamTextMuted = Color(0xFF94A3B8)        // Futuristic Cool Gray

// Material Theme standard fallbacks
val Purple80 = Color(0xFF7C5CFF)
val PurpleGrey80 = Color(0xFF94A3B8)
val Pink80 = Color(0xFFFF7A1A)

val Purple40 = Color(0xFF7C5CFF)
val PurpleGrey40 = Color(0xFF111827)
val Pink40 = Color(0xFFFF7A1A)
