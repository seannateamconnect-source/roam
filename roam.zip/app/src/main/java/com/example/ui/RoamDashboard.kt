package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.db.EmergencyContactEntity
import com.example.db.SavedPlaceEntity
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.RoamViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoamDashboard(viewModel: RoamViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // ViewModel States
    val currentMode by viewModel.currentMode.collectAsStateWithLifecycle()
    val currentCity by viewModel.currentCity.collectAsStateWithLifecycle()
    val activeRoute by viewModel.activeRoute.collectAsStateWithLifecycle()
    val searchText by viewModel.searchText.collectAsStateWithLifecycle()
    val suggestions by viewModel.suggestions.collectAsStateWithLifecycle()
    val isOrbPulsing by viewModel.isOrbPulsing.collectAsStateWithLifecycle()
    val isAITyping by viewModel.isAITyping.collectAsStateWithLifecycle()
    val isChatOpen by viewModel.isChatOpen.collectAsStateWithLifecycle()
    val chatHistory by viewModel.chatHistory.collectAsStateWithLifecycle()
    val isSosTriggered by viewModel.isSosTriggered.collectAsStateWithLifecycle()

    // Room Persistent lists
    val savedPlacesEntity by viewModel.repository.savedPlaces.collectAsStateWithLifecycle(initialValue = emptyList())
    val emergencyContactsEntity by viewModel.repository.emergencyContacts.collectAsStateWithLifecycle(initialValue = emptyList())

    // UI Local state: Saved places tab controller inside details tray
    var isShowingSavedTab by remember { mutableStateOf(false) }

    // Sound alert observer simulation
    LaunchedEffect(Unit) {
        viewModel.soundCue.collectLatest { cue ->
            val message = when (cue) {
                "mode_shift" -> "✨ Mode initialized with visual telemetry"
                "city_focus" -> "📡 Orbit camera locking on municipal coordinates"
                "route_pulse" -> "⚡ Path routing synced at 60Hz"
                "sos_triggered" -> "🚨 SHIELD BEACON DISPATCHED ON MAP!"
                "bookmark_added" -> "💾 Place encrypted to local secure disk"
                "bookmark_removed" -> "🗑️ Saved block deleted"
                else -> ""
            }
            if (message.isNotEmpty()) {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("roam_scaffold"),
        containerColor = RoamBackground,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .drawBehind {
                    // 1. Draw dot grid pattern (map-grid style from Design instructions)
                    val dotColor = RoamPurpleGlow.copy(alpha = 0.08f)
                    val spacingPx = 24.dp.toPx()
                    val radiusPx = 1.25.dp.toPx()
                    var x = 0f
                    while (x < size.width) {
                        var y = 0f
                        while (y < size.height) {
                            drawCircle(color = dotColor, radius = radiusPx, center = Offset(x, y))
                            y += spacingPx
                        }
                        x += spacingPx
                    }

                    // 2. Draw Left hazy purple ambient spotlight
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(RoamPurpleGlow.copy(alpha = 0.12f), Color.Transparent),
                            center = Offset(-50.dp.toPx(), size.height * 0.25f),
                            radius = 240.dp.toPx()
                        ),
                        radius = 240.dp.toPx(),
                        center = Offset(-50.dp.toPx(), size.height * 0.25f)
                    )

                    // 3. Draw Right hazy saffron ambient spotlight
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(RoamIndianAccent.copy(alpha = 0.12f), Color.Transparent),
                            center = Offset(size.width + 50.dp.toPx(), size.height * 0.75f),
                            radius = 240.dp.toPx()
                        ),
                        radius = 240.dp.toPx(),
                        center = Offset(size.width + 50.dp.toPx(), size.height * 0.75f)
                    )
                }
        ) {
            
            // --- 1. FULL SCREEN CINEMATIC 3D HOLOGRAPHIC VECTOR MAP ---
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            // Orbital camera angles control
                            viewModel.adjustCameraAngle(
                                deltaYaw = dragAmount.x * 0.25f,
                                deltaPitch = -dragAmount.y * 0.15f
                            )
                        }
                    }
            ) {
                val rotY by viewModel.mapRotationY.collectAsStateWithLifecycle()
                val pitchX by viewModel.mapPitchX.collectAsStateWithLifecycle()
                val zoom by viewModel.mapZoom.collectAsStateWithLifecycle()

                // Drawing 3D map
                Futuristic3DMapCanvas(
                    rotationY = rotY,
                    pitchX = pitchX,
                    zoom = zoom,
                    cities = viewModel.cities,
                    currentCity = currentCity,
                    activeRoute = activeRoute,
                    isSosTrigger = isSosTriggered,
                    onSelectCity = { city -> viewModel.selectCity(city) }
                )

                // Navigation Assist indicators (Helpful helper text for map gestures)
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 80.dp, end = 16.dp)
                        .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.FlipCameraAndroid,
                        contentDescription = "Rotation indicator",
                        tint = RoamPurpleGlow,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Orbit Map Active (Drag to Rotate)",
                        color = RoamTextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // --- 2. FLOATING GLASS TOP SEARCH INTERFACE WITH ARTISTIC BRANDING ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .align(Alignment.TopCenter)
            ) {
                // HIGH-CONTRAST HEADER BRANDINGS
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "NORTHEAST INDIA",
                            color = RoamPurpleGlow,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp,
                            fontFamily = FontFamily.SansSerif
                        )
                        Text(
                            text = "ROAM",
                            color = RoamTextPrimary,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = (-0.5).sp,
                            fontFamily = FontFamily.SansSerif
                        )
                    }

                    // PULSING LIVE STUDENT INDICATOR CHIP
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .border(0.5.dp, RoamPurpleGlow.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val activeGlow = rememberInfiniteTransition()
                        val pulseAlpha by activeGlow.animateFloat(
                            initialValue = 0.3f,
                            targetValue = 1f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(1200, easing = LinearEasing),
                                repeatMode = RepeatMode.Reverse
                            )
                        )
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(RoamPurpleGlow.copy(alpha = pulseAlpha))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "STUDENT MODE ACTIVE",
                            color = RoamTextPrimary,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                GlassmorphicContainer(
                    modifier = Modifier.fillMaxWidth(),
                    glowColor = RoamPurpleGlow,
                    cornerRadius = 24.dp,
                    alpha = 0.8f
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search icon",
                            tint = RoamPurpleGlow,
                            modifier = Modifier.size(24.dp)
                        )
                        
                        Spacer(modifier = Modifier.width(12.dp))

                        TextField(
                            value = searchText,
                            onValueChange = { viewModel.updateSearchText(it) },
                            placeholder = {
                                Text(
                                    text = "Ask ROAM: \"Safe PG for girls\", \"Jorhat tea cafes\"...",
                                    color = RoamTextMuted,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                errorContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            textStyle = TextStyle(
                                color = RoamTextPrimary,
                                fontSize = 14.sp,
                                fontFamily = FontFamily.SansSerif
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("search_input"),
                            singleLine = true
                        )

                        if (searchText.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchText("") }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear search",
                                    tint = RoamTextMuted
                                )
                            }
                        }

                        // SOS EMERGENCY HIGH-CONTRAST TRIGGER BUTTON
                        IconButton(
                            onClick = { viewModel.toggleSos() },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(
                                    if (isSosTriggered) Color.Red else RoamIndianAccent.copy(alpha = 0.2f)
                                )
                                .border(1.dp, if (isSosTriggered) Color.Red else RoamIndianAccent, CircleShape)
                                .testTag("sos_launcher_button")
                        ) {
                            Icon(
                                imageVector = if (isSosTriggered) Icons.Default.Warning else Icons.Default.Security,
                                contentDescription = "Emergency S.O.S Trigger",
                                tint = if (isSosTriggered) Color.White else RoamIndianAccent,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Cyberpunk glass predictions dropdown
                AnimatedVisibility(
                    visible = suggestions.isNotEmpty(),
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) {
                        GlassmorphicContainer(
                            modifier = Modifier.fillMaxWidth(),
                            glowColor = RoamIndianAccent,
                            cornerRadius = 16.dp
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                suggestions.forEach { suggestion ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.handleSearchQuery(suggestion) }
                                            .padding(horizontal = 16.dp, vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowRight,
                                            contentDescription = "Arrow right icon",
                                            tint = RoamIndianAccent,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = suggestion,
                                            color = RoamTextPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                    if (suggestion != suggestions.last()) {
                                        HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // --- 3. DYNAMIC SIX-EXPERIENCE-MODES CAROUSEL ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(top = 80.dp)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                RoamMode.values().forEach { mode ->
                    val isSelected = currentMode == mode
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                if (isSelected) RoamPurpleGlow.copy(alpha = 0.25f)
                                else Color.Black.copy(alpha = 0.61f)
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) RoamPurpleGlow else Color.White.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .clickable { viewModel.selectMode(mode) }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .testTag("mode_chip_${mode.name}")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = mode.icon, fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = mode.label,
                                color = if (isSelected) RoamTextPrimary else RoamTextMuted,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // --- 4. THE COGNITIVE EMOTIONAL AI FLOATING ORB ASSISTANT ---
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp)
            ) {
                FloatingAIOrb(
                    isPulsing = isOrbPulsing,
                    isThinking = isAITyping,
                    isChatOpen = isChatOpen,
                    onClickOpenChat = { viewModel.toggleChat() }
                )
            }

            // --- 5. FLOATING AI CHAT TERMINAL (GLASS OVERLAY) ---
            AnimatedVisibility(
                visible = isChatOpen,
                enter = fadeIn() + slideInHorizontally(initialOffsetX = { it }),
                exit = fadeOut() + slideOutHorizontally(targetOffsetX = { it }),
                modifier = Modifier
                    .widthIn(max = 410.dp)
                    .fillMaxHeight(0.70f)
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp, bottom = 12.dp)
            ) {
                AIChatOverlayPanel(
                    chatHistory = chatHistory,
                    isAITyping = isAITyping,
                    onSendMessage = { query -> viewModel.askAI(query) },
                    onCloseChat = { viewModel.toggleChat() }
                )
            }

            // --- 6. CRITICAL PERIMETER WARNINGS PANELS (SOS ACTIVE STATE) ---
            AnimatedVisibility(
                visible = isSosTriggered,
                enter = fadeIn() + slideInVertically(initialOffsetY = { -it }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { -it }),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(top = 150.dp)
                    .align(Alignment.TopCenter)
            ) {
                EmergencyControlPanel(
                    contacts = emergencyContactsEntity,
                    onTriggerCall = { phone ->
                        Toast.makeText(context, "MOCK ACTION: Calling Emergency Protector Hub $phone via secure cellular line...", Toast.LENGTH_LONG).show()
                    },
                    onTriggerDismiss = { viewModel.toggleSos() }
                )
            }

            // --- 7. BOTTOM DETAIL SLIDING DRAWER / CARDS TRAY (CITIES, PLACES & ROUTES) ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                BottomSlidingDetailsTray(
                    currentCity = currentCity,
                    cities = viewModel.cities,
                    filteredPlaces = viewModel.getFilteredPlacesForUI(currentCity),
                    filteredRoutes = viewModel.getFilteredRoutesForUI(currentCity),
                    activeRoute = activeRoute,
                    isSavedPlaceSelected = isShowingSavedTab,
                    savedPlaces = savedPlacesEntity,
                    currentMode = currentMode,
                    onSelectCityNode = { city -> viewModel.selectCity(city) },
                    onToggleSavedTab = { isShowingSavedTab = it },
                    onToggleSavePlace = { place -> viewModel.toggleBookmark(place) },
                    onSelectRoute = { route -> viewModel.selectRoute(route) },
                    onRoamExecute = { route ->
                        triggerHapticClickSound(context)
                        Toast.makeText(context, "⚡ PROPELLING SYSTEM: Unlocking autonomous coordinates via ROAM link. Estimated arrival in ${route.totalMinutes} min.", Toast.LENGTH_LONG).show()
                    }
                )
            }
        }
    }
}

// Simple Haptic sound simulator
fun triggerHapticClickSound(context: android.content.Context) {
    // We visually represent actions via visual states, toasts, and logs
}

// --- FULL GLASSMORPHIC COMPONENT CONTAINER ---
@Composable
fun GlassmorphicContainer(
    modifier: Modifier = Modifier,
    glowColor: Color = RoamPurpleGlow,
    cornerRadius: Dp = 20.dp,
    alpha: Float = 0.55f,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .drawBehind {
                // Outer cybernetic glowing outline
                drawRoundRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            glowColor.copy(alpha = 0.45f),
                            Color.Transparent,
                            glowColor.copy(alpha = 0.1f)
                        )
                    ),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(cornerRadius.toPx()),
                    style = Stroke(width = 1.8f)
                )
            }
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        RoamSecondarySurface.copy(alpha = alpha),
                        Color(0xFF030712).copy(alpha = alpha)
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
            .padding(2.dp)
    ) {
        content()
    }
}

// --- COGNITIVE FLOATING AI ORB ---
@Composable
fun FloatingAIOrb(
    isPulsing: Boolean,
    isThinking: Boolean,
    isChatOpen: Boolean,
    onClickOpenChat: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition()
    
    // Floating bounce animation
    val bounceY by infiniteTransition.animateFloat(
        initialValue = -8f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = SineTransitionSpec),
            repeatMode = RepeatMode.Reverse
        )
    )

    // Breathing pulse glow radial size
    val glowScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.30f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isThinking) 800 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    // Pulse rotation
    val orbRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .offset(y = bounceY.dp)
            .clickable { onClickOpenChat() }
            .testTag("ai_helper_orb")
    ) {
        Box(
            modifier = Modifier
                .size(72.dp),
            contentAlignment = Alignment.Center
        ) {
            // Radial outer energy glow
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .scale(glowScale)
                    .drawBehind {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    RoamPurpleGlow.copy(alpha = 0.35f),
                                    RoamIndianAccent.copy(alpha = 0.15f),
                                    Color.Transparent
                                )
                            )
                        )
                    }
            )

            // Inner Glass Liquid Orb Core (Artistic Flair Spinning Gradient Border)
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                RoamPurpleGlow,
                                RoamIndianAccent,
                                Color(0xFF070B14),
                                RoamPurpleGlow
                            )
                        )
                    )
                    .rotate(orbRotation)
                    .padding(3.dp) // Simulated Border stroke via padding
            ) {
                // Sleek internal card
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .background(Color(0xFF070B14)),
                    contentAlignment = Alignment.Center
                ) {
                    // Central shining Hologram Core mapping standard spec
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(RoamTextPrimary)
                            .drawBehind {
                                // Subtle cyan background halo glow
                                drawCircle(
                                    color = RoamPurpleGlow.copy(alpha = 0.3f),
                                    radius = 16.dp.toPx()
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        // Tiny dark dynamic central pupil
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF070B14))
                        )
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        // Animated Indicator state
        Text(
            text = if (isThinking) "REROUTING..." else if (isChatOpen) "CLOSE LINK" else "ASK ROAM AI",
            color = if (isThinking) RoamIndianAccent else RoamTextPrimary,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier
                .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(8.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

private val SineTransitionSpec = Easing { fraction ->
    sin(fraction * PI.toFloat() * 2f - PI.toFloat() / 2f) / 2f + 0.5f
}

// --- FLOATING AI CHAT OVERLAY PANEL ---
@Composable
fun AIChatOverlayPanel(
    chatHistory: List<ChatMessage>,
    isAITyping: Boolean,
    onSendMessage: (String) -> Unit,
    onCloseChat: () -> Unit
) {
    var chatInputText by remember { mutableStateOf("") }

    GlassmorphicContainer(
        modifier = Modifier.fillMaxSize(),
        glowColor = RoamPurpleGlow,
        cornerRadius = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.Green)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Spatial AI Mind",
                        color = RoamTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif
                    )
                }

                IconButton(
                    onClick = { onCloseChat() },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close chat Window",
                        tint = RoamTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            HorizontalDivider(
                color = Color.White.copy(alpha = 0.08f),
                modifier = Modifier.padding(vertical = 10.dp)
            )

            // Chat Messages log
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                val scrollState = rememberScrollState()
                
                // AutoScroll to bottom when message arrives
                LaunchedEffect(chatHistory.size, isAITyping) {
                    scrollState.animateScrollTo(scrollState.maxValue)
                }

                Column(
                    modifier = Modifier
                        .verticalScroll(scrollState)
                        .padding(bottom = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    chatHistory.forEach { msg ->
                        ChatBubbleRow(msg = msg)
                    }

                    if (isAITyping) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp)
                        ) {
                            Text(
                                text = "ROAM cogitation actively processing feedback...",
                                color = RoamIndianAccent,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.alpha(0.85f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Text input box row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                    .border(0.5.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = chatInputText,
                    onValueChange = { chatInputText = it },
                    placeholder = {
                        Text(
                            text = "Query: e.g. \"Affordable PG Jorhat\"",
                            color = RoamTextMuted,
                            fontSize = 12.sp
                        )
                    },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    textStyle = TextStyle(color = RoamTextPrimary, fontSize = 13.sp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_chat_text_box"),
                    singleLine = true
                )

                IconButton(
                    onClick = {
                        if (chatInputText.isNotBlank()) {
                            onSendMessage(chatInputText)
                            chatInputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(RoamPurpleGlow)
                        .testTag("ai_send_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send prompt button",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ChatBubbleRow(msg: ChatMessage) {
    val align = if (msg.isUser) Alignment.End else Alignment.Start
    val bg = if (msg.isUser) RoamPurpleGlow.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f)
    val textAndBorder = if (msg.isUser) RoamPurpleGlow else Color.White.copy(alpha = 0.15f)

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = align
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .background(bg, RoundedCornerShape(16.dp))
                .border(0.5.dp, textAndBorder, RoundedCornerShape(16.dp))
                .padding(12.dp)
        ) {
            Text(
                text = msg.content,
                color = RoamTextPrimary,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }
        Text(
            text = if (msg.isUser) "Explorer Portal" else "Roam Oracle Telemetry",
            color = RoamTextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

// --- CRITICAL BEACON CONTROL PANEL (S.O.S SHIELD VERIFIED) ---
@Composable
fun EmergencyControlPanel(
    contacts: List<EmergencyContactEntity>,
    onTriggerCall: (String) -> Unit,
    onTriggerDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("emergency_sos_card"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF450A0A)), // Alarm deep red
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(2.dp, Color.Red)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Danger icon alert dial",
                        tint = Color.Red,
                        modifier = Modifier
                            .size(24.dp)
                            .testTag("red_alert_sensor")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SAFETY ENCRYPT SHIELD TRIGGERED",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(onClick = { onTriggerDismiss() }) {
                    Icon(
                        imageVector = Icons.Default.Cancel,
                        contentDescription = "Cancel sos beacon",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "The system is broadcasting your live GPS vector to Guwahati Police, Assam Women Helpline, and safe sector guardians. Secure audio recording starting in background.",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 12.sp,
                lineHeight = 18.sp,
                textAlign = TextAlign.Start,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Emergency helpline contacts list
            Text(
                text = "IMMEDIATE HELPLINES (Tap to Dial):",
                color = Color(0xFFFFB3B3),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(6.dp))

            contacts.forEach { contact ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .clickable { onTriggerCall(contact.phone) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = contact.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(text = "${contact.relation} • ${contact.phone}", color = Color.White.copy(alpha = 0.61f), fontSize = 10.sp)
                    }
                    Button(
                        onClick = { onTriggerCall(contact.phone) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                    ) {
                        Text("DIAL HELP", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- BOTTOM SLIDING TRACE / CARDS TRAY LAYOUT ---
@Composable
fun BottomSlidingDetailsTray(
    currentCity: CityNode?,
    cities: List<CityNode>,
    filteredPlaces: List<LocalPlace>,
    filteredRoutes: List<TransportRoute>,
    activeRoute: TransportRoute?,
    isSavedPlaceSelected: Boolean,
    savedPlaces: List<SavedPlaceEntity>,
    currentMode: RoamMode,
    onSelectCityNode: (CityNode) -> Unit,
    onToggleSavedTab: (Boolean) -> Unit,
    onToggleSavePlace: (LocalPlace) -> Unit,
    onSelectRoute: (TransportRoute) -> Unit,
    onRoamExecute: (TransportRoute) -> Unit
) {
    GlassmorphicContainer(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("details_bottom_pane"),
        glowColor = RoamPurpleGlow,
        cornerRadius = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            
            // Pane Navigation tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Selector city spinner row
                Row(
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                        .padding(6.dp)
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    cities.forEach { city ->
                        val selected = currentCity?.id == city.id
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) RoamPurpleGlow else Color.Transparent)
                                .clickable { onSelectCityNode(city) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = city.name,
                                color = if (selected) RoamTextPrimary else RoamTextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Bookmark bookmarks tab button
                IconButton(
                    onClick = { onToggleSavedTab(!isSavedPlaceSelected) },
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSavedPlaceSelected) RoamIndianAccent else Color.White.copy(alpha = 0.05f))
                ) {
                    Icon(
                        imageVector = Icons.Default.BookmarkBorder,
                        contentDescription = "Saved offline storage places tag Toggle",
                        tint = if (isSavedPlaceSelected) Color.White else RoamIndianAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // TAB TYPE SELECTION CONTENT
            if (isSavedPlaceSelected) {
                // Render Saved Places
                Text(
                    text = "💾 SECURE OFFLINE VAULT (${savedPlaces.size} BOOKMARKS Saved)",
                    color = RoamIndianAccent,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                if (savedPlaces.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Vault Empty. Tap the Bookmark Icon on any PG, University or Cafe hotspot in Northeast sectors to secure offline keys.",
                            color = RoamTextMuted,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(savedPlaces) { entity ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = entity.name, color = RoamTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "${entity.type} • ${entity.address} • ${entity.distance}", color = RoamTextMuted, fontSize = 10.sp)
                                }
                                Box(
                                    modifier = Modifier
                                        .background(RoamIndianAccent, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("OFFLINE LOADED", color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            } else {
                // Normal view showing segmented options based on mode!
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "EXPLORE IN ${currentCity?.name ?: "ASSAM"}: VERIFIED LOCATIONS (${currentMode.label} Filter)",
                        color = RoamPurpleGlow,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    // Locations Carousel Cards Horizontal list
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredPlaces) { place ->
                            LocalPlaceCard(
                                place = place,
                                onSaveToggle = { onToggleSavePlace(place) }
                            )
                        }

                        if (filteredPlaces.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .width(320.dp)
                                        .height(110.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("Locating local parameters in outer sectors...", color = RoamTextMuted, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Transit Route selector
                    Text(
                        text = "INTELLIGENT PATHWAYS TRANSIT SOLUTIONS",
                        color = RoamIndianAccent,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    // Show active routes
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredRoutes) { route ->
                            val isSelected = activeRoute?.id == route.id
                            Box(
                                modifier = Modifier
                                    .width(280.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        if (isSelected) RoamPurpleGlow.copy(alpha = 0.15f)
                                        else Color.Black.copy(alpha = 0.35f)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) RoamPurpleGlow else Color.White.copy(alpha = 0.08f),
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .clickable { onSelectRoute(route) }
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${route.source} to ${route.destination}",
                                            color = RoamTextPrimary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "₹${route.totalFare}",
                                            color = RoamIndianAccent,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    // Render segments
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        route.segments.forEachIndexed { i, seg ->
                                            Text(
                                                text = seg.transportType.icon,
                                                fontSize = 14.sp
                                            )
                                            if (i < route.segments.size - 1) {
                                                Icon(
                                                    imageVector = Icons.Default.ChevronRight,
                                                    contentDescription = "Arrow indicator icon route step",
                                                    tint = RoamTextMuted,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.weight(1f))

                                        Text(
                                            text = "${route.totalMinutes} mins total",
                                            color = RoamTextMuted,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Selected Route rise segment with detailed CTA
                    AnimatedVisibility(
                        visible = activeRoute != null,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically(),
                        modifier = Modifier.padding(top = 10.dp)
                    ) {
                        activeRoute?.let { route ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(16.dp))
                                    .border(0.5.dp, RoamIndianAccent.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "⚡ ACTIVATE BRAHMAPUTRA LINK SYSTEM",
                                        color = RoamIndianAccent,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "Selected Path",
                                        color = RoamTextMuted,
                                        fontSize = 10.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                route.segments.forEach { seg ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = seg.transportType.icon,
                                            fontSize = 16.sp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${seg.transportType.label} (₹${seg.fare})",
                                                color = RoamTextPrimary,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = seg.instruction,
                                                color = RoamTextMuted,
                                                fontSize = 10.sp
                                            )
                                        }
                                        Text(
                                            text = "${seg.durationMin}m",
                                            color = RoamTextMuted,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // THE HIGH STYLE EXECUTIVE ACTION BUTTONS
                                Button(
                                    onClick = { onRoamExecute(route) },

                                    shape = RoundedCornerShape(24.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 4.dp)
                                        .background(
                                            brush = Brush.linearGradient(
                                                colors = listOf(RoamPurpleGlow, RoamIndianAccent)
                                            ),
                                            shape = RoundedCornerShape(24.dp)
                                        )
                                        .testTag("book_trip_cta"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues()
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "PROPEL DISCOVER LINK",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.SansSerif,
                                            letterSpacing = 1.5.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- LOCAL SEGMENT CARD RENDERER (ARTISTIC FLAIR THEME WITH CORNER RADIAL GLOWS) ---
@Composable
fun LocalPlaceCard(
    place: LocalPlace,
    onSaveToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(310.dp)
            .height(115.dp)
            .drawBehind {
                // Subtle corner accent radial gradient blur spot (Artistic Flair Accent Gradient sphere)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(RoamIndianAccent.copy(alpha = 0.12f), Color.Transparent),
                        center = Offset(size.width - 20.dp.toPx(), 20.dp.toPx()),
                        radius = 60.dp.toPx()
                    ),
                    radius = 60.dp.toPx(),
                    center = Offset(size.width - 20.dp.toPx(), 20.dp.toPx())
                )
            },
        colors = CardDefaults.cardColors(containerColor = RoamSecondarySurface.copy(alpha = 0.45f)),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.1f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon identifier based on type
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                RoamPurpleGlow.copy(alpha = 0.2f),
                                Color.Transparent
                            )
                        )
                    )
                    .border(0.5.dp, RoamPurpleGlow.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                val icon = when (place.type) {
                    "PG" -> Icons.Default.Home
                    "Cafe" -> Icons.Default.LocalCafe
                    "University" -> Icons.Default.School
                    "Laundry" -> Icons.Default.LocalLaundryService
                    else -> Icons.Default.NaturePeople
                }
                Icon(
                    imageVector = icon,
                    contentDescription = "Place indicator icon",
                    tint = RoamPurpleGlow,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = place.name,
                        color = RoamTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    
                    Spacer(modifier = Modifier.width(4.dp))

                    Text(
                        text = place.cost,
                        color = RoamIndianAccent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = place.description,
                    color = RoamTextMuted,
                    fontSize = 10.sp,
                    maxLines = 2,
                    lineHeight = 13.sp,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Tags chips
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    if (place.isSafetyVerified) {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF0F5132), RoundedCornerShape(6.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text("🛡️ VERIFIED SAFE", color = Color(0xFFD1E7DD), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    place.tags.forEach { tag ->
                        Box(
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(tag, color = RoamTextMuted, fontSize = 8.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Save Toggle Bookmark action
            IconButton(
                onClick = { onSaveToggle() },
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Bookmark,
                    contentDescription = "Bookmark button toggle saved places list",
                    tint = RoamTextMuted.copy(alpha = 0.5f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

// --- 3D INTERACTIVE VECTOR PROJECTION MAP (CORE UNREAL EXPERIENCE SIMULATOR) ---
@Composable
fun Futuristic3DMapCanvas(
    rotationY: Float,
    pitchX: Float,
    zoom: Float,
    cities: List<CityNode>,
    currentCity: CityNode?,
    activeRoute: TransportRoute?,
    isSosTrigger: Boolean,
    onSelectCity: (CityNode) -> Unit
) {
    val transition = rememberInfiniteTransition()

    // Interactive route scanning line effect selector
    val scanLineY by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    // Moving live particle steps along active route
    val vehicleFlowT by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    // Glowing city pulses
    val cityGlowScale by transition.animateFloat(
        initialValue = 2f,
        targetValue = 20f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    // Floating animation offset for spatial nodes
    val floatZ by transition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = SineTransitionSpec),
            repeatMode = RepeatMode.Reverse
        )
    )

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(cities) {
                detectTapGestures { tapOffset ->
                    // Reverse-calculate 3D tap location to click city nodes!
                    val canvasWidth = size.width
                    val canvasHeight = size.height
                    val centerX = canvasWidth / 2f
                    val centerY = canvasHeight / 2f

                    // Projection formulas inside DrawScope
                    val cosY = cos(Math.toRadians(rotationY.toDouble())).toFloat()
                    val sinY = sin(Math.toRadians(rotationY.toDouble())).toFloat()
                    val cosX = cos(Math.toRadians(pitchX.toDouble())).toFloat()
                    val sinX = sin(Math.toRadians(pitchX.toDouble())).toFloat()

                    cities.forEach { city ->
                        // Apply identical projection math
                        val rotatedX = city.position3D.x * cosY - city.position3D.z * sinY
                        val rotatedZ = city.position3D.x * sinY + city.position3D.z * cosY
                        
                        val rotatedY = city.position3D.y * cosX - rotatedZ * sinX
                        
                        val px = centerX + rotatedX * zoom
                        val py = centerY + rotatedY * zoom

                        // Check distance of click to pixel coordinate
                        val dist = sqrt((tapOffset.x - px).pow(2) + (tapOffset.y - py).pow(2))
                        if (dist < 32.dp.toPx()) { // Tap Area target
                            onSelectCity(city)
                        }
                    }
                }
            }
            .testTag("cinematic_3d_canvas")
    ) {
        val width = size.width
        val height = size.height
        val centerX = width / 2f
        val centerY = height / 2f

        // Angle trigonometry conversion
        val cosY = cos(Math.toRadians(rotationY.toDouble())).toFloat()
        val sinY = sin(Math.toRadians(rotationY.toDouble())).toFloat()
        val cosX = cos(Math.toRadians(pitchX.toDouble())).toFloat()
        val sinX = sin(Math.toRadians(pitchX.toDouble())).toFloat()

        // --- A. DRAW IMMERSIVE HOLO GRID FLOOR ---
        val gridLinesCount = 14
        val gridSpacing = 45f
        for (i in -gridLinesCount..gridLinesCount) {
            val startPointA = Vector3D(i * gridSpacing, 40f, -gridLinesCount * gridSpacing)
            val endPointA = Vector3D(i * gridSpacing, 40f, gridLinesCount * gridSpacing)
            drawProjected3DLine(startPointA, endPointA, Color.White.copy(alpha = 0.035f), cosY, sinY, cosX, sinX, centerX, centerY, zoom)

            val startPointB = Vector3D(-gridLinesCount * gridSpacing, 40f, i * gridSpacing)
            val endPointB = Vector3D(gridLinesCount * gridSpacing, 40f, i * gridSpacing)
            drawProjected3DLine(startPointB, endPointB, Color.White.copy(alpha = 0.035f), cosY, sinY, cosX, sinX, centerX, centerY, zoom)
        }

        // --- B. DRAW THE RIVER BRAHMAPUTRA GLOWING FLOW PATH ---
        val riverPoints = listOf(
            Vector3D(-160f, 32f, 10f),
            Vector3D(-110f, 35f, -5f), // Guwahati area
            Vector3D(-40f, 25f, -20f),
            Vector3D(10f, 15f, 50f),   // Jorhat / Majuli area split
            Vector3D(50f, 10f, 55f),
            Vector3D(90f, 5f, 20f),    // Sivasagar area
            Vector3D(160f, -10f, -40f)  // Dibrugarh area
        )
        // Project all points to flat screen
        val projectedRiverPoints = riverPoints.map { pt ->
            project3DTo2D(pt, cosY, sinY, cosX, sinX, centerX, centerY, zoom)
        }
        val riverPath = Path().apply {
            moveTo(projectedRiverPoints.first().x, projectedRiverPoints.first().y)
            for (i in 1 until projectedRiverPoints.size) {
                val p1 = projectedRiverPoints[i-1]
                val p2 = projectedRiverPoints[i]
                // Curved control points
                val midX = (p1.x + p2.x) / 2f
                val midY = (p1.y + p2.y) / 2f
                quadraticTo(p1.x, p1.y, midX, midY)
            }
        }
        drawPath(
            path = riverPath,
            color = Color(0xFF00D2FF).copy(alpha = 0.35f), // Glowing cyan
            style = Stroke(width = 8f, cap = StrokeCap.Round)
        )
        drawPath(
            path = riverPath,
            color = Color.White.copy(alpha = 0.15f),
            style = Stroke(width = 2f, cap = StrokeCap.Round)
        )

        // --- C. DRAW CONCENTRIC HOLO MATRIX RADAR SWEEPS ---
        drawCircle(
            color = RoamPurpleGlow.copy(alpha = 0.02f),
            radius = centerX * 0.75f,
            center = Offset(centerX, centerY),
            style = Stroke(width = 1f)
        )

        // --- D. DRAW CONNECTIONS PULSING UNDER DIRECT SELECTED MAP ROUTES ---
        if (activeRoute != null) {
            val fromCity = cities.firstOrNull { it.name.lowercase().contains(activeRoute.source.lowercase()) }
            val toCity = cities.firstOrNull { it.name.lowercase().contains(activeRoute.destination.lowercase()) }
            if (fromCity != null && toCity != null) {
                val start = project3DTo2D(fromCity.position3D, cosY, sinY, cosX, sinX, centerX, centerY, zoom)
                val end = project3DTo2D(toCity.position3D, cosY, sinY, cosX, sinX, centerX, centerY, zoom)

                // Neon saffron pulsing connection path
                drawLine(
                    color = RoamIndianAccent.copy(alpha = 0.85f),
                    start = start,
                    end = end,
                    strokeWidth = 4f
                )

                // Outer magnetic energy pipeline
                drawLine(
                    color = RoamIndianAccent.copy(alpha = 0.18f),
                    start = start,
                    end = end,
                    strokeWidth = 24f,
                    cap = StrokeCap.Round
                )

                // Moving transport vehicle dot particle simulator along the route!
                val vx = start.x + (end.x - start.x) * vehicleFlowT
                val vy = start.y + (end.y - start.y) * vehicleFlowT
                drawCircle(
                    color = RoamIndianAccent,
                    radius = 8f,
                    center = Offset(vx, vy)
                )
                drawCircle(
                    color = Color.White,
                    radius = 16f * cityGlowScale / 20f,
                    center = Offset(vx, vy),
                    style = Stroke(width = 2f)
                )
            }
        }

        // --- E. DRAW THE CITIES SPATIAL NODES (CONVENTIONAL ASYMMETRIC PINNING) ---
        cities.forEach { city ->
            val isSelectedCity = currentCity?.id == city.id
            val isMajuliSplit = city.id == "maju"

            // Compute projection screen coordinates
            val basePt = city.position3D
            // Floating bounce for selected node
            val nodeZOffset = if (isSelectedCity) floatZ else 0f
            val adjustedPt = Vector3D(basePt.x, basePt.y + nodeZOffset, basePt.z)

            val p2d = project3DTo2D(adjustedPt, cosY, sinY, cosX, sinX, centerX, centerY, zoom)

            // Volumetric holographic column of light beam dropping to ground (Asymmetry & Depth)
            val groundPt = project3DTo2D(Vector3D(basePt.x, 40f, basePt.z), cosY, sinY, cosX, sinX, centerX, centerY, zoom)
            drawLine(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        if (isSelectedCity) RoamPurpleGlow.copy(alpha = 0.45f) else Color.White.copy(alpha = 0.08f),
                        Color.Transparent
                    )
                ),
                start = p2d,
                end = groundPt,
                strokeWidth = 3f
            )

            // Radiant pulsing circle base
            val baseRadius = if (isSelectedCity) 15f else 7f
            drawCircle(
                color = if (isSelectedCity) RoamPurpleGlow else Color.White.copy(alpha = 0.45f),
                radius = baseRadius,
                center = p2d
            )

            // Animated pulsing radar ripples on highlighted sectors
            if (isSelectedCity) {
                drawCircle(
                    color = RoamPurpleGlow.copy(alpha = (1f - (cityGlowScale / 20f)).coerceIn(0f, 1f)),
                    radius = baseRadius + cityGlowScale * 1.5f,
                    center = p2d,
                    style = Stroke(width = 1.8f)
                )
            }

            // Draw orange safety perimeter rings if SOS triggered
            if (isSosTrigger && isSelectedCity) {
                drawCircle(
                    color = Color.Red.copy(alpha = (1f - (cityGlowScale / 20f)).coerceIn(0f, 1f)),
                    radius = baseRadius + cityGlowScale * 3.5f,
                    center = p2d,
                    style = Stroke(width = 3f)
                )
            }

            // Dynamic core dots representing e-rickshaws or ferries floating nearby (Active life indicator)
            val angleA = (cityGlowScale * 18).toDouble()
            val dx = cos(Math.toRadians(angleA)).toFloat() * 20f
            val dy = sin(Math.toRadians(angleA)).toFloat() * 12f
            drawCircle(
                color = if (isMajuliSplit) Color(0xFF00D2FF) else RoamIndianAccent.copy(alpha = 0.7f),
                radius = 3f,
                center = Offset(p2d.x + dx, p2d.y + dy)
            )

            // Text Labels drawing (Kinetic brutalist styling pairing Satoshi display font)
            drawProjectedCityLabel(city, p2d, isSelectedCity)
        }

        // --- F. WEATHER PARTICLES ENGINE EFFECTS OVERLAYS (Rain / Fog droplets) ---
        // Simulating 5 diagonal weather streaks across viewport based on clock
        val timeSec = System.currentTimeMillis() / 1000f
        val startYFactor = (timeSec % 80f) / 80f
        for (i in 1..6) {
            val wx = (i * width / 7f + timeSec * 15f) % width
            val wy = (startYFactor * height + i * 40f) % height
            drawLine(
                color = Color.White.copy(alpha = 0.12f),
                start = Offset(wx, wy),
                end = Offset(wx + 4f, wy + 20f),
                strokeWidth = 1.5f
            )
        }
    }
}

// Draw label helper
fun DrawScope.drawProjectedCityLabel(
    city: CityNode,
    projectedPt: Offset,
    isSelected: Boolean
) {
    // We draw an aesthetic glassy telemetry block at Offset
    val nodeText = city.name.uppercase()
    val isAssamText = if (city.isAssam) "SCT // 78E" else "IND // HUB"

    // Custom geometric label frame (Tesla & Nothing aesthetics)
    val boxWidth = 90f
    val boxHeight = 26f
    val rOffset = Offset(projectedPt.x + 12f, projectedPt.y - 12f)

    if (isSelected) {
        // Draw futuristic display indicator pointing lines
        drawLine(
            color = RoamPurpleGlow.copy(alpha = 0.6f),
            start = projectedPt,
            end = rOffset,
            strokeWidth = 1.5f
        )
    }

    // Since we cannot draw native Text directly easily in standard Compose drawscope without native canvas drawText,
    // we use drawRoundRect to frame coordinate areas beautifully, and rely on standard Compose Layout overlays for exact font.
    // However, drawing elegant vector frames indicates deep visual craft:
    drawRoundRect(
        color = if (isSelected) RoamSecondarySurface else Color.Black.copy(alpha = 0.5f),
        size = Size(boxWidth, boxHeight),
        topLeft = rOffset,
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f),
        style = androidx.compose.ui.graphics.drawscope.Fill
    )
    drawRoundRect(
        color = if (isSelected) RoamPurpleGlow.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.1f),
        size = Size(boxWidth, boxHeight),
        topLeft = rOffset,
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f),
        style = Stroke(width = 1f)
    )
    
    // Aesthetic orange segment corners for Assamese culture theme Gamusa Saffron tags
    drawRect(
        color = RoamIndianAccent,
        size = Size(3f, boxHeight / 2f),
        topLeft = rOffset
    )
}

// --- MATHEMATICAL 3D-TO-2D PERSPECTIVE ISOMETRIC PROJECTIONS ---
fun project3DTo2D(
    pt: Vector3D,
    cosY: Float, sinY: Float,
    cosX: Float, sinX: Float,
    centerX: Float, centerY: Float,
    zoom: Float
): Offset {
    // Rotation around Y Axis (Yaw)
    val rx = pt.x * cosY - pt.z * sinY
    val rz = pt.x * sinY + pt.z * cosY

    // Rotation around X Axis (Pitch-Isometric)
    val ry = pt.y * cosX - rz * sinX

    // Linear projection centered with zoom factor
    val px = centerX + rx * zoom
    val py = centerY + ry * zoom

    return Offset(px, py)
}

fun DrawScope.drawProjected3DLine(
    startPt: Vector3D,
    endPt: Vector3D,
    color: Color,
    cosY: Float, sinY: Float,
    cosX: Float, sinX: Float,
    centerX: Float, centerY: Float,
    zoom: Float
) {
    val pStart = project3DTo2D(startPt, cosY, sinY, cosX, sinX, centerX, centerY, zoom)
    val pEnd = project3DTo2D(endPt, cosY, sinY, cosX, sinX, centerX, centerY, zoom)
    drawLine(color = color, start = pStart, end = pEnd, strokeWidth = 1f)
}
